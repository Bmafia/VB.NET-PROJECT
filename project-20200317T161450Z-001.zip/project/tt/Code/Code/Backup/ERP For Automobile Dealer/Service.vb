
Imports System.Data
Imports System.Data.SqlClient

Public Class Service
    Dim con As SqlConnection
    Dim cmd, cmmd As SqlCommand
    Dim ds As DataSet
    Dim qry, qry1 As String
    Dim ada As SqlDataAdapter
    Dim i, j As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub Service_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = Date.Today
        con = New SqlConnection("Data Source=.;Initial Catalog=automobile;Integrated Security=True")

        qry = "select * from vehicle"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "vehicle")
        i = ds.Tables("vehicle").Rows.Count
        For j = 0 To i - 1
            ComboBox1.Items.Remove(ds.Tables("vehicle").Rows(j)(0))
            ComboBox1.Items.Add(ds.Tables("vehicle").Rows(j)(0))
        Next

        qry = "select * from customer"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "customer")
        i = ds.Tables("customer").Rows.Count
        For j = 0 To i - 1
            ComboBox2.Items.Remove(ds.Tables("customer").Rows(j)(0))
            ComboBox2.Items.Add(ds.Tables("customer").Rows(j)(0))
        Next


        qry = "select * from customer"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "customer")
        i = ds.Tables("customer").Rows.Count
        For j = 0 To i - 1
            ComboBox3.Items.Remove(ds.Tables("customer").Rows(j)(1))
            ComboBox3.Items.Add(ds.Tables("customer").Rows(j)(1))
        Next
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try

            qry = "select VehName,VehColor from vehicle where VehId=" + ComboBox1.Text.ToString()
            cmd = New SqlCommand(qry, con)
            con.Open()
            ada = New SqlDataAdapter(cmd)
            con.Close()
            ds = New DataSet()
            ada.Fill(ds, "vehicle")
            TextBox2.Text = ds.Tables("vehicle").Rows(0)(0)
            TextBox3.Text = ds.Tables("vehicle").Rows(0)(1)
             
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or ComboBox3.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else

            qry1 = "Insert into service values( '" & TextBox1.Text & "','" & ComboBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & DateTimePicker1.Text & "')"
            cmmd = New SqlCommand(qry1, con)
            con.Open()
            cmmd.ExecuteNonQuery()
            con.Close()
            MsgBox("Successfully Saved")


            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            ComboBox1.Text = ""
            ComboBox2.Text = ""
            ComboBox3.Text = ""
            DateTimePicker1.Text = ""

        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        DateTimePicker1.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        ComboBox3.SelectedIndex = ComboBox2.SelectedIndex
        Try

            qry = "select Address from Customer where CusId=" + ComboBox2.Text.ToString()
            cmd = New SqlCommand(qry, con)
            con.Open()
            ada = New SqlDataAdapter(cmd)
            con.Close()
            ds = New DataSet()
            ada.Fill(ds, "Customer")
            TextBox4.Text = ds.Tables("Customer").Rows(0)(0)


        Catch ex As Exception
        End Try
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        ComboBox2.SelectedIndex = ComboBox3.SelectedIndex
    End Sub
End Class