Imports System.Data
Imports System.Data.SqlClient
Public Class Purchase
    Dim con As SqlConnection
    Dim cmd, cmmd As SqlCommand
    Dim ds As DataSet
    Dim qry, qry1 As String
    Dim ada As SqlDataAdapter
    Dim i, j As Integer
    Dim a, b, c As Integer
    Private Sub Purchase_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=.;Initial Catalog=automobile;Integrated Security=True")

        qry = "select * from stock"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "stock")
        i = ds.Tables("stock").Rows.Count
        For j = 0 To i - 1
            ComboBox1.Items.Remove(ds.Tables("stock").Rows(j)(0))
            ComboBox1.Items.Add(ds.Tables("stock").Rows(j)(0))
        Next




        qry = "select * from supplier"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "supplier")
        i = ds.Tables("supplier").Rows.Count
        For j = 0 To i - 1
            ComboBox3.Items.Remove(ds.Tables("supplier").Rows(j)(0))
            ComboBox3.Items.Add(ds.Tables("supplier").Rows(j)(0))
        Next

        qry = "select * from supplier"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "supplier")
        i = ds.Tables("supplier").Rows.Count
        For j = 0 To i - 1
            ComboBox4.Items.Remove(ds.Tables("supplier").Rows(j)(1))
            ComboBox4.Items.Add(ds.Tables("supplier").Rows(j)(1))
        Next

       

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try

            qry = "select VehName,VehColor,Qty from stock where StockId=" + ComboBox1.Text.ToString()
            cmd = New SqlCommand(qry, con)
            con.Open()
            ada = New SqlDataAdapter(cmd)
            con.Close()
            ds = New DataSet()
            ada.Fill(ds, "Stock")
            TextBox1.Text = ds.Tables("Stock").Rows(0)(0)
            TextBox2.Text = ds.Tables("Stock").Rows(0)(1)
            TextBox3.Text = ds.Tables("Stock").Rows(0)(2)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        ComboBox4.SelectedIndex = ComboBox3.SelectedIndex

    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox4.SelectedIndexChanged
        ComboBox3.SelectedIndex = ComboBox4.SelectedIndex

    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        a = Val(TextBox4.Text)
        b = Val(TextBox3.Text)
        c = Val(a + b)
        TextBox5.Text = c

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or ComboBox3.Text = "" Or ComboBox4.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else
            qry1 = "Insert into Purchase values('" & ComboBox1.Text & "' ,'" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox5.Text & "', '" & ComboBox3.Text & "','" & ComboBox4.Text & "', '" & Label1.Text & "')"
            cmmd = New SqlCommand(qry1, con)
            con.Open()
            cmmd.ExecuteNonQuery()

            qry = "update stock set Qty='" & TextBox5.Text & "' ,DateAndTime='" & Label1.Text & "'where StockId=" + ComboBox1.Text + ""
            cmd = New SqlCommand(qry, con)
            cmd.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Saved")

            ComboBox1.Text = ""
            ComboBox3.Text = ""
            ComboBox4.Text = ""
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ComboBox1.Text = ""
        ComboBox3.Text = ""
        ComboBox4.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub
End Class