Imports System.Data
Imports System.Data.SqlClient
Public Class Vehicle
    Dim con As SqlConnection
    Dim cmd, cmmd As SqlCommand
    Dim ds As DataSet
    Dim qry As String
    Dim ada As SqlDataAdapter
    Dim i, j As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub Vehicle_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=.;Initial Catalog=automobile;Integrated Security=True")
        qry = "select * from stock"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "stock")
        i = ds.Tables("stock").Rows.Count
        For j = 0 To i - 1
            ComboBox1.Items.Remove(ds.Tables("stock").Rows(j)(0))
            ComboBox1.Items.Add(ds.Tables("stock").Rows(j)(0))
        Next

    End Sub

    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else
            cmd = New SqlCommand("Insert into Vehicle values('" & ComboBox1.Text & "','" & TextBox6.Text & "', '" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & Label1.Text & "')", con)
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("Successfully Saved")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            ComboBox1.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        ComboBox1.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try

            qry = "select VehName,VehColor,price from stock where StockId=" + ComboBox1.Text.ToString()
            cmd = New SqlCommand(qry, con)
            con.Open()
            ada = New SqlDataAdapter(cmd)
            con.Close()
            ds = New DataSet()
            ada.Fill(ds, "stock")
            TextBox6.Text = ds.Tables("stock").Rows(0)(0)
            TextBox1.Text = ds.Tables("stock").Rows(0)(1)
            TextBox2.Text = ds.Tables("stock").Rows(0)(2)

        Catch ex As Exception
        End Try
    End Sub
End Class