Public Class Admin

    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.TextLength <> 0 And TextBox2.TextLength = 0 Then
            MsgBox("Enter Password")

        ElseIf TextBox1.TextLength = 0 And TextBox2.TextLength <> 0 Then
            MsgBox("Enter Adminname")

        ElseIf TextBox1.TextLength = 0 And TextBox2.TextLength = 0 Then

            MsgBox("Enter Adminname and Password")

        ElseIf TextBox1.Text = "Admin" And TextBox2.Text = "Admin" Then
            MsgBox("Welcome")

            Home.Show()
            Me.Hide()
        Else
            MsgBox("Invalid User")


        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Application.Exit()
    End Sub

    Private Sub Admin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class