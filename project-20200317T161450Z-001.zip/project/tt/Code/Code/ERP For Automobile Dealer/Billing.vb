Imports System.Data
Imports System.Data.SqlClient
Public Class Billing
    Dim con As SqlConnection
    Dim cmd, cmmd As SqlCommand
    Dim ds As DataSet
    Dim qry, qry1 As String
    Dim ada As SqlDataAdapter
    Dim i, j As Integer
    Dim a, b, c, x, y, z, a1, b1, a2, b2, c2, d2 As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub Billing_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=BHARATH-PC;Initial Catalog=automobile;Persist Security Info=True;User ID=sa;Password=sql")

        qry = "select * from stock"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "stock")
        i = ds.Tables("stock").Rows.Count
        For j = 0 To i - 1
            ComboBox1.Items.Remove(ds.Tables("stock").Rows(j)(0))
            ComboBox1.Items.Add(ds.Tables("stock").Rows(j)(0))
        Next

        qry = "select * from customer"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "customer")
        i = ds.Tables("customer").Rows.Count
        For j = 0 To i - 1
            ComboBox2.Items.Remove(ds.Tables("customer").Rows(j)(0))
            ComboBox2.Items.Add(ds.Tables("customer").Rows(j)(0))
        Next


        qry = "select * from customer"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "customer")
        i = ds.Tables("customer").Rows.Count
        For j = 0 To i - 1
            ComboBox3.Items.Remove(ds.Tables("customer").Rows(j)(1))
            ComboBox3.Items.Add(ds.Tables("customer").Rows(j)(1))
        Next


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or ComboBox3.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else

            qry1 = "Insert into billing values( '" & ComboBox1.Text & "','" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" & Label1.Text & "')"
            cmmd = New SqlCommand(qry1, con)
            con.Open()
            cmmd.ExecuteNonQuery()

            qry = "update stock set Qty='" & TextBox9.Text & "' ,DateAndTime='" & Label1.Text & "'where StockId=" + ComboBox1.Text + ""
            cmd = New SqlCommand(qry, con)
            cmd.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Saved")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            TextBox7.Text = ""
            TextBox9.Text = ""
            ComboBox1.Text = ""
            ComboBox2.Text = ""
            ComboBox3.Text = ""
            Button4.Visible = True
            Button1.Visible = False

        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox9.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        Button4.Visible = True
        Button1.Visible = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try

            qry = "select VehName,VehColor,Price,Qty from stock where StockId=" + ComboBox1.Text.ToString()
            cmd = New SqlCommand(qry, con)
            con.Open()
            ada = New SqlDataAdapter(cmd)
            con.Close()
            ds = New DataSet()
            ada.Fill(ds, "Stock")
            TextBox1.Text = ds.Tables("Stock").Rows(0)(0)
            TextBox2.Text = ds.Tables("Stock").Rows(0)(1)
            TextBox3.Text = ds.Tables("Stock").Rows(0)(2)
            TextBox8.Text = ds.Tables("Stock").Rows(0)(3)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        a = Val(TextBox4.Text)
        b = Val(TextBox8.Text)
        c = Val(b - a)
        TextBox9.Text = c

     
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        ComboBox3.SelectedIndex = ComboBox2.SelectedIndex
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        ComboBox2.SelectedIndex = ComboBox3.SelectedIndex
    End Sub

    Private Sub cal()
        x = Val(TextBox4.Text)
        y = Val(TextBox3.Text)
        z = x * y
        TextBox7.Text = z

        a1 = Val(TextBox5.Text)
        z = Val(TextBox7.Text)
        b1 = Val(a1 + z)
        TextBox7.Text = b1
        a2 = Val(TextBox7.Text)
        b2 = Val(TextBox6.Text)
        c2 = Val(a2 / 100 * 4)
        d2 = Val(b1 + c2)
        TextBox7.Text = d2



    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        cal()
        Button4.Visible = False
        Button1.Visible = True
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub
End Class