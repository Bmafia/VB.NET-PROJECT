Imports System.Data
Imports System.Data.SqlClient
Public Class Vehicle
    Dim con As SqlConnection
    Dim cmd, cmmd As SqlCommand
    Dim ds As DataSet
    Dim qry As String
    Dim ada As SqlDataAdapter
    Dim i, j As Integer

    Dim adp As SqlDataAdapter

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub Vehicle_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=BHARATH-PC;Initial Catalog=automobile;Persist Security Info=True;User ID=sa;Password=sql")

        id()
        add()



    End Sub

    Private Sub id()
        Try
            Dim p As String
            qry = "select VehId from vehicle"
            cmd = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet
            adp.Fill(ds, "vehicle")
            i = ds.Tables("vehicle").Rows.Count
            p = ds.Tables("vehicle").Rows(i - 1)(0)
            p = Mid(p, 2)
            p = Val(p) + 1
            If Len(p) = 1 Then
                p = "000" + p
            ElseIf Len(p) = 2 Then
                p = "00" + p
            ElseIf Len(p) = 3 Then
                p = "0" + p
            End If
            ComboBox1.Text = "V" + p
        Catch ex As Exception
            ComboBox1.Text = "V0001"
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else
            qry = "insert into vehicle values('" & ComboBox1.Text & "','" & TextBox6.Text & "', '" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & Label1.Text & "')"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("Successfully Saved")

            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            ComboBox1.Text = ""
        End If
        id()
        add()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        ComboBox1.Text = ""
        id()
        add()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged




        Try

            qry = "select * from vehicle where VehId='" + ComboBox1.SelectedItem + "'"
            cmd = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet
            adp.Fill(ds, "vehicle")
            ComboBox1.Text = ds.Tables("vehicle").Rows(0)(0)
            TextBox1.Text = ds.Tables("vehicle").Rows(0)(1)
            TextBox2.Text = ds.Tables("vehicle").Rows(0)(2)
            TextBox3.Text = ds.Tables("vehicle").Rows(0)(3)
            TextBox4.Text = ds.Tables("vehicle").Rows(0)(4)
            TextBox5.Text = ds.Tables("vehicle").Rows(0)(5)
            TextBox6.Text = ds.Tables("vehicle").Rows(0)(6)

        Catch ex As Exception
            MsgBox("Please Search Correct customer Code", MsgBoxStyle.Information)
        End Try





    End Sub
    Private Sub add()
        ComboBox1.Items.Clear()
        qry = "select * from vehicle"
        cmd = New SqlCommand(qry, con)
        adp = New SqlDataAdapter(cmd)
        ds = New DataSet
        adp.Fill(ds, "vehicle")
        i = ds.Tables("vehicle").Rows.Count
        Dim j As Integer
        For j = 0 To i - 1
            ComboBox1.Items.Add(ds.Tables("vehicle").Rows(j)(0))
        Next
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If ComboBox1.Text = "" Or TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Please Search Any vehicle Code Then Edit", MsgBoxStyle.Information)
        Else
            qry = "update vehicle set VehName='" + TextBox1.Text + "',VehColor='" + TextBox2.Text + "',VehPrice='" + TextBox3.Text + "',DateandTime='" + Label1.Text + "',EngNo='" + TextBox4.Text + "',ChasNo='" + TextBox5.Text + "',FrameNo='" + TextBox6.Text + "' where VehId='" + ComboBox1.Text + "'"
            cmd = New SqlCommand(qry, con)
            con.Open()
            cmd.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Edited")
        End If

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""

        id()


    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        id()
        add()

    End Sub
End Class