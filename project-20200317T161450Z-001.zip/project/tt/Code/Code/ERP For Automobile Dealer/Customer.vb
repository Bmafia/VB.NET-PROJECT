Imports System.Data
Imports System.Data.SqlClient

Public Class Customer
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim qry As String
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub Dealer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=BHARATH-PC;Initial Catalog=automobile;Persist Security Info=True;User ID=sa;Password=sql")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else

            cmd = New SqlCommand("Insert into customer values( '" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & Label1.Text & "' )", con)
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("Successfully Saved")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub
End Class