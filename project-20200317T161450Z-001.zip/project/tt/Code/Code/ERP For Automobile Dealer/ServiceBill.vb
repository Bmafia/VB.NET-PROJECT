Imports System.Data
Imports System.Data.SqlClient

Public Class ServiceBill
    Dim con As SqlConnection
    Dim cmd, cmmd As SqlCommand
    Dim ds As DataSet
    Dim qry, qry1 As String
    Dim ada As SqlDataAdapter
    Dim i, j As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = DateAndTime.Now
    End Sub

    Private Sub ServiceBill_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=BHARATH-PC;Initial Catalog=automobile;Persist Security Info=True;User ID=sa;Password=sql")

        qry = "select * from service"
        con.Open()
        cmd = New SqlCommand(qry, con)
        con.Close()
        ada = New SqlDataAdapter(cmd)
        ds = New DataSet()
        ada.Fill(ds, "service")
        i = ds.Tables("service").Rows.Count
        For j = 0 To i - 1
            ComboBox1.Items.Remove(ds.Tables("service").Rows(j)(0))
            ComboBox1.Items.Add(ds.Tables("service").Rows(j)(0))
        Next
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Or ComboBox1.Text = "" Then
            MsgBox("Please Enter All Values Then Save", MsgBoxStyle.Information)
        Else

            qry1 = "Insert into serbill values( '" & ComboBox1.Text & "','" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" & Label1.Text & "')"
            cmmd = New SqlCommand(qry1, con)
            con.Open()
            cmmd.ExecuteNonQuery()
            con.Close()
            MsgBox("Successfully Saved")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            TextBox7.Text = ""
            TextBox8.Text = ""
            TextBox9.Text = ""
            ComboBox1.Text = ""
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        ComboBox1.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Home.Show()
        Me.Hide()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try

            qry = "select SerDate,VehId,VehName,VehColor,CusId,CusName,Address,Fault from service where SerId=" + ComboBox1.Text.ToString()
            cmd = New SqlCommand(qry, con)
            con.Open()
            ada = New SqlDataAdapter(cmd)
            con.Close()
            ds = New DataSet()
            ada.Fill(ds, "service")
            TextBox1.Text = ds.Tables("service").Rows(0)(0)
            TextBox2.Text = ds.Tables("service").Rows(0)(1)
            TextBox3.Text = ds.Tables("service").Rows(0)(2)
            TextBox4.Text = ds.Tables("service").Rows(0)(3)
            TextBox5.Text = ds.Tables("service").Rows(0)(4)
            TextBox6.Text = ds.Tables("service").Rows(0)(5)
            TextBox7.Text = ds.Tables("service").Rows(0)(6)
            TextBox8.Text = ds.Tables("service").Rows(0)(7)
        Catch ex As Exception
        End Try
    End Sub
End Class