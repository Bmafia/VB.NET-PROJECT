﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.CUSTOMERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EMPLOYEEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PRODUCTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PURCHASEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PURCHASERETURNToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SALESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SALESRETURNToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BILLINGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.STOCKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.REPORTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CUSTOMERToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EMPLOYEEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PRODUCTToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PURCHASEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PURCHASERETURNToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SALESToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SALESToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.BILLINGToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.StockToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CUSTOMERToolStripMenuItem, Me.EMPLOYEEToolStripMenuItem, Me.PRODUCTToolStripMenuItem, Me.PURCHASEToolStripMenuItem, Me.PURCHASERETURNToolStripMenuItem, Me.SALESToolStripMenuItem, Me.SALESRETURNToolStripMenuItem, Me.BILLINGToolStripMenuItem, Me.STOCKToolStripMenuItem, Me.REPORTToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1008, 26)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CUSTOMERToolStripMenuItem
        '
        Me.CUSTOMERToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSTOMERToolStripMenuItem.Name = "CUSTOMERToolStripMenuItem"
        Me.CUSTOMERToolStripMenuItem.Size = New System.Drawing.Size(97, 22)
        Me.CUSTOMERToolStripMenuItem.Text = "CUSTOMER"
        '
        'EMPLOYEEToolStripMenuItem
        '
        Me.EMPLOYEEToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPLOYEEToolStripMenuItem.Name = "EMPLOYEEToolStripMenuItem"
        Me.EMPLOYEEToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.EMPLOYEEToolStripMenuItem.Text = "EMPLOYEE"
        '
        'PRODUCTToolStripMenuItem
        '
        Me.PRODUCTToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PRODUCTToolStripMenuItem.Name = "PRODUCTToolStripMenuItem"
        Me.PRODUCTToolStripMenuItem.Size = New System.Drawing.Size(87, 22)
        Me.PRODUCTToolStripMenuItem.Text = "PRODUCT"
        '
        'PURCHASEToolStripMenuItem
        '
        Me.PURCHASEToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PURCHASEToolStripMenuItem.Name = "PURCHASEToolStripMenuItem"
        Me.PURCHASEToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.PURCHASEToolStripMenuItem.Text = "PURCHASE"
        '
        'PURCHASERETURNToolStripMenuItem
        '
        Me.PURCHASERETURNToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PURCHASERETURNToolStripMenuItem.Name = "PURCHASERETURNToolStripMenuItem"
        Me.PURCHASERETURNToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PURCHASERETURNToolStripMenuItem.Text = "PURCHASE RETURN"
        '
        'SALESToolStripMenuItem
        '
        Me.SALESToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SALESToolStripMenuItem.Name = "SALESToolStripMenuItem"
        Me.SALESToolStripMenuItem.Size = New System.Drawing.Size(62, 22)
        Me.SALESToolStripMenuItem.Text = "SALES"
        '
        'SALESRETURNToolStripMenuItem
        '
        Me.SALESRETURNToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SALESRETURNToolStripMenuItem.Name = "SALESRETURNToolStripMenuItem"
        Me.SALESRETURNToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.SALESRETURNToolStripMenuItem.Text = "SALES RETURN"
        '
        'BILLINGToolStripMenuItem
        '
        Me.BILLINGToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BILLINGToolStripMenuItem.Name = "BILLINGToolStripMenuItem"
        Me.BILLINGToolStripMenuItem.Size = New System.Drawing.Size(77, 22)
        Me.BILLINGToolStripMenuItem.Text = "BILLING"
        '
        'STOCKToolStripMenuItem
        '
        Me.STOCKToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.STOCKToolStripMenuItem.Name = "STOCKToolStripMenuItem"
        Me.STOCKToolStripMenuItem.Size = New System.Drawing.Size(67, 22)
        Me.STOCKToolStripMenuItem.Text = "STOCK"
        '
        'REPORTToolStripMenuItem
        '
        Me.REPORTToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CUSTOMERToolStripMenuItem1, Me.EMPLOYEEToolStripMenuItem1, Me.PRODUCTToolStripMenuItem1, Me.PURCHASEToolStripMenuItem1, Me.PURCHASERETURNToolStripMenuItem1, Me.SALESToolStripMenuItem1, Me.SALESToolStripMenuItem2, Me.BILLINGToolStripMenuItem1, Me.StockToolStripMenuItem1})
        Me.REPORTToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.REPORTToolStripMenuItem.Name = "REPORTToolStripMenuItem"
        Me.REPORTToolStripMenuItem.Size = New System.Drawing.Size(74, 22)
        Me.REPORTToolStripMenuItem.Text = "REPORT"
        '
        'CUSTOMERToolStripMenuItem1
        '
        Me.CUSTOMERToolStripMenuItem1.Name = "CUSTOMERToolStripMenuItem1"
        Me.CUSTOMERToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.CUSTOMERToolStripMenuItem1.Text = "CUSTOMER"
        '
        'EMPLOYEEToolStripMenuItem1
        '
        Me.EMPLOYEEToolStripMenuItem1.Name = "EMPLOYEEToolStripMenuItem1"
        Me.EMPLOYEEToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.EMPLOYEEToolStripMenuItem1.Text = "EMPLOYEE"
        '
        'PRODUCTToolStripMenuItem1
        '
        Me.PRODUCTToolStripMenuItem1.Name = "PRODUCTToolStripMenuItem1"
        Me.PRODUCTToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.PRODUCTToolStripMenuItem1.Text = "PRODUCT"
        '
        'PURCHASEToolStripMenuItem1
        '
        Me.PURCHASEToolStripMenuItem1.Name = "PURCHASEToolStripMenuItem1"
        Me.PURCHASEToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.PURCHASEToolStripMenuItem1.Text = "PURCHASE"
        '
        'PURCHASERETURNToolStripMenuItem1
        '
        Me.PURCHASERETURNToolStripMenuItem1.Name = "PURCHASERETURNToolStripMenuItem1"
        Me.PURCHASERETURNToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.PURCHASERETURNToolStripMenuItem1.Text = "PURCHASE RETURN"
        '
        'SALESToolStripMenuItem1
        '
        Me.SALESToolStripMenuItem1.Name = "SALESToolStripMenuItem1"
        Me.SALESToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.SALESToolStripMenuItem1.Text = "SALES "
        '
        'SALESToolStripMenuItem2
        '
        Me.SALESToolStripMenuItem2.Name = "SALESToolStripMenuItem2"
        Me.SALESToolStripMenuItem2.Size = New System.Drawing.Size(208, 22)
        Me.SALESToolStripMenuItem2.Text = "SALES RETURN"
        '
        'BILLINGToolStripMenuItem1
        '
        Me.BILLINGToolStripMenuItem1.Name = "BILLINGToolStripMenuItem1"
        Me.BILLINGToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.BILLINGToolStripMenuItem1.Text = "BILLING"
        '
        'StockToolStripMenuItem1
        '
        Me.StockToolStripMenuItem1.Name = "StockToolStripMenuItem1"
        Me.StockToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.StockToolStripMenuItem1.Text = "STOCK"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(51, 22)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MistyRose
        Me.ClientSize = New System.Drawing.Size(1008, 716)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents CUSTOMERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EMPLOYEEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PRODUCTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PURCHASEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PURCHASERETURNToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALESRETURNToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BILLINGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CUSTOMERToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EMPLOYEEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PRODUCTToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PURCHASEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PURCHASERETURNToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALESToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALESToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BILLINGToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STOCKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
