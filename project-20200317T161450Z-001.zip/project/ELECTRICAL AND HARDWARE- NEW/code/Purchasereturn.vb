﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Purchasereturn
    Dim con As New SqlConnection("Data Source=ELCOT-PC\SQLEXPRESS;Initial Catalog=electrical;Persist Security Info=True;User ID=sa;Password=sql")
    Dim qry, qry1 As String
    Dim com As New SqlCommand
    Dim adp, adp1 As New SqlDataAdapter
    Dim ds As New DataSet
    Dim i As Integer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or ComboBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Please Fill All Details", MsgBoxStyle.Information, "Electrical & hardware")
        Else

            qry = "insert into purchasereturn values('" + TextBox1.Text + "','" + ComboBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')"
            com = New SqlCommand(qry, con)
            con.Open()
            com.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Saved", MsgBoxStyle.Information, "Electrical & hardware")
        End If

        Try
            Dim p As String
            qry = "select purretid from purchasereturn"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "purchasereturn")
            i = ds.Tables("purchasereturn").Rows.Count
            p = ds.Tables("purchasereturn").Rows(i - 1)(0)
            p = Mid(p, 2)
            p = Val(p) + 1
            If Len(p) = 1 Then
                p = "00" + p
            ElseIf Len(p) = 2 Then
                p = "0" + p
            End If
            TextBox1.Text = "P" + p

        Catch ex As Exception
            TextBox1.Text = "P001"
        End Try
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or ComboBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Please Search Any One Details Then Edit", MsgBoxStyle.Information, "Electrical & hardware")
        Else
            qry = "update purchasereturn set purid='" + ComboBox1.Text + "',pname='" + TextBox2.Text + "',qty='" + TextBox3.Text + "',price='" + TextBox4.Text + "',reaforret='" + TextBox5.Text + "'where purretid='" + TextBox1.Text + "'"
            com = New SqlCommand(qry, con)
            con.Open()
            com.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Updated", MsgBoxStyle.Information, "Electrical & hardware")
        End If
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        Try
            Dim p As String
            qry = "select purretid from purchasereturn"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "purchasereturn")
            i = ds.Tables("purchasereturn").Rows.Count
            p = ds.Tables("purchasereturn").Rows(i - 1)(0)
            p = Mid(p, 2)
            p = Val(p) + 1
            If Len(p) = 1 Then
                p = "00" + p
            ElseIf Len(p) = 2 Then
                p = "0" + p
            End If
            TextBox1.Text = "P" + p

        Catch ex As Exception
            TextBox1.Text = "P001"
        End Try

        Try
            qry = "select * from purchasereturn"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "purchasereturn")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Electrical & hardware")
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Dim s As String
            s = InputBox("Enter purchasereturn id")
            qry = "select * from purchasereturn where purretid='" + s + "'"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "purchasereturn")
            TextBox1.Text = ds.Tables("purchasereturn").Rows(0)(0)
            ComboBox1.Text = ds.Tables("purchasereturn").Rows(0)(1)
            TextBox2.Text = ds.Tables("purchasereturn").Rows(0)(2)
            TextBox3.Text = ds.Tables("purchasereturn").Rows(0)(3)
            TextBox4.Text = ds.Tables("purchasereturn").Rows(0)(4)
            TextBox5.Text = ds.Tables("purchasereturn").Rows(0)(5)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Electrical & hardware")
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        con.Open()
        qry = "delete from purchasereturn where purretid='" & TextBox1.Text & "' "
        com = New SqlCommand(qry, con)
        com.ExecuteNonQuery()
        MsgBox("successfully deleted", MsgBoxStyle.Information, "Electrical & hardware")
        con.Close()
        TextBox1.Text = ""
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Purchasereturn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Fill()
    End Sub
    Private Sub fill()
        Try
            qry = "select * from purchase"
            con.Open()
            com = New SqlCommand(qry, con)
            con.Close()
            adp = New SqlDataAdapter(com)
            ds = New DataSet()
            adp.Fill(ds, "purchase")
            i = ds.Tables("purchase").Rows.Count
            For j = 0 To i - 1
                ComboBox1.Items.Remove(ds.Tables("purchase").Rows(j)(0))
                ComboBox1.Items.Add(ds.Tables("purchase").Rows(j)(0))
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try
            qry = "select * from purchase where purid='" + ComboBox1.Text.ToString() + "'"
            com = New SqlCommand(qry, con)
            con.Open()
            adp = New SqlDataAdapter(com)
            con.Close()
            ds = New DataSet()
            adp.Fill(ds, "purchase")
            'ComboBox1.Text = ds.Tables("customer").Rows(0)(1)
            TextBox2.Text = ds.Tables("purchase").Rows(0)(1)
        Catch ex As Exception
        End Try
    End Sub
End Class