﻿Public Class Stockrep

End Class