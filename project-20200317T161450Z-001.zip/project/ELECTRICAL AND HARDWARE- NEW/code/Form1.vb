﻿Public Class Form1
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Please Enter Username and Password Then Login", MsgBoxStyle.Information)
        ElseIf TextBox1.Text = "Admin" And TextBox2.Text = "Admin" Then
            Me.Hide()
            Form2.Show()
        Else
            MsgBox("Invalid Username And Password", MsgBoxStyle.Information)
            TextBox1.Text = ""
            TextBox2.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
