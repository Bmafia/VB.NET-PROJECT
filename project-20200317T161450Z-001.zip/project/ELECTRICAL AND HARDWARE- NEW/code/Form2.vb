﻿Public Class Form2

    Private Sub CUSTOMERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CUSTOMERToolStripMenuItem.Click
        Customer.Show()
    End Sub

    Private Sub EMPLOYEEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EMPLOYEEToolStripMenuItem.Click
        Employee.Show()
    End Sub

    Private Sub PRODUCTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRODUCTToolStripMenuItem.Click
        Product.Show()
    End Sub

    Private Sub PURCHASEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PURCHASEToolStripMenuItem.Click
        Purchase.Show()
    End Sub

    Private Sub PURCHASERETURNToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PURCHASERETURNToolStripMenuItem.Click
        Purchasereturn.Show()
    End Sub

    Private Sub SALESToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SALESToolStripMenuItem.Click
        Sales.Show()
    End Sub

    Private Sub SALESRETURNToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SALESRETURNToolStripMenuItem.Click
        Salesreturn.Show()
    End Sub

    Private Sub BILLINGToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BILLINGToolStripMenuItem.Click
        Billing.Show()
    End Sub

    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        End
    End Sub

    Private Sub CUSTOMERToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CUSTOMERToolStripMenuItem1.Click
        Customerrep.Show()
    End Sub

    Private Sub EMPLOYEEToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EMPLOYEEToolStripMenuItem1.Click
        Employeerep.Show()
    End Sub

    Private Sub PRODUCTToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRODUCTToolStripMenuItem1.Click
        productrep.Show()
    End Sub

    Private Sub PURCHASEToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PURCHASEToolStripMenuItem1.Click
        Purchaserep.Show()
    End Sub

    Private Sub PURCHASERETURNToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PURCHASERETURNToolStripMenuItem1.Click
        Purchaseretrep.Show()
    End Sub

    Private Sub SALESToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SALESToolStripMenuItem1.Click
        Salesrep.Show()
    End Sub

    Private Sub SALESToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SALESToolStripMenuItem2.Click
        Salesretrep.Show()
    End Sub

    Private Sub BILLINGToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BILLINGToolStripMenuItem1.Click
        billingrep.show()
    End Sub

    Private Sub STOCKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STOCKToolStripMenuItem.Click
        Stock.Show()
    End Sub

    Private Sub StockToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StockToolStripMenuItem1.Click
        Stockrep.Show()
    End Sub
End Class