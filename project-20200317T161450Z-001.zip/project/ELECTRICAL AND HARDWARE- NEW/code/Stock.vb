﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Stock
    Dim con As New SqlConnection("Data Source=ELCOT-PC\SQLEXPRESS;Initial Catalog=electrical;Persist Security Info=True;User ID=sa;Password=sql")
    Dim qry, qry1 As String
    Dim com As New SqlCommand
    Dim adp, adp1 As New SqlDataAdapter
    Dim ds As New DataSet
    Dim i As Integer
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or ComboBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Please Fill All Details", MsgBoxStyle.Information, "Electrical & hardware")
        Else

            qry = "insert into stock values('" + TextBox1.Text + "','" + ComboBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')"
            com = New SqlCommand(qry, con)
            con.Open()
            com.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Saved", MsgBoxStyle.Information, "Electrical & hardware")
        End If

        Try
            Dim p As String
            qry = "select stid from stock"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "stock")
            i = ds.Tables("stock").Rows.Count
            p = ds.Tables("stock").Rows(i - 1)(0)
            p = Mid(p, 2)
            p = Val(p) + 1
            If Len(p) = 1 Then
                p = "00" + p
            ElseIf Len(p) = 2 Then
                p = "0" + p
            End If
            TextBox1.Text = "S" + p

        Catch ex As Exception
            TextBox1.Text = "S001"
        End Try
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or ComboBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Please Search Any One Details Then Edit", MsgBoxStyle.Information, "Electrical & hardware")
        Else
            qry = "update stock set pname='" + ComboBox1.Text + "',qty='" + TextBox2.Text + "',rt='" + TextBox3.Text + "'where stid='" + TextBox1.Text + "'"
            com = New SqlCommand(qry, con)
            con.Open()
            com.ExecuteScalar()
            con.Close()
            MsgBox("Successfully Updated", MsgBoxStyle.Information, "Electrical & hardware")
        End If
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        Try
            Dim p As String
            qry = "select stid from stock"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "stock")
            i = ds.Tables("stock").Rows.Count
            p = ds.Tables("stock").Rows(i - 1)(0)
            p = Mid(p, 2)
            p = Val(p) + 1
            If Len(p) = 1 Then
                p = "00" + p
            ElseIf Len(p) = 2 Then
                p = "0" + p
            End If
            TextBox1.Text = "S" + p

        Catch ex As Exception
            TextBox1.Text = "S001"
        End Try

        Try
            qry = "select * from stock"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "stock")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Electrical & hardware")
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Dim s As String
            s = InputBox("Enter stock id")
            qry = "select * from stock where stid='" + s + "'"
            com = New SqlCommand(qry, con)
            adp = New SqlDataAdapter(com)
            ds = New DataSet
            adp.Fill(ds, "stock")
            TextBox1.Text = ds.Tables("stock").Rows(0)(0)
            ComboBox1.Text = ds.Tables("stock").Rows(0)(1)
            TextBox2.Text = ds.Tables("stock").Rows(0)(2)
            TextBox3.Text = ds.Tables("stock").Rows(0)(3)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Electrical & hardware")
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        con.Open()
        qry = "delete from stock where stid='" & TextBox1.Text & "' "
        com = New SqlCommand(qry, con)
        com.ExecuteNonQuery()
        MsgBox("successfully deleted", MsgBoxStyle.Information, "Electrical & hardware")
        con.Close()
        TextBox1.Text = ""
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class